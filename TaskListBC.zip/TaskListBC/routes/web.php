<?php

use Illuminate\Support\Facades\Route;
use Razorpay\Api\Api;

// use Razorpay\Api\Api;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
   
});

Route::get('/','front\UserController@login')->name('login');
Route::get('register','front\UserController@register')->name('register');
Route::post('submitlogin','front\UserController@submitlogin')->name('submitlogin');
Route::post('submitregister','front\UserController@submitregister')->name('submitregister');

Route::group(['middleware' => 'auth:web'], function()
{
	Route::post('getWeatherData','front\UserController@getWeatherData')->name('getWeatherData');
	
	Route::get('/logout','front\UserController@logout')->name('logout');
	
});











