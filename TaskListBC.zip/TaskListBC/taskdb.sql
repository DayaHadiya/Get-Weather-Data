-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2022 at 06:08 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `taskdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `user_id`, `name`, `created_at`, `updated_at`) VALUES
(1, '2', 'ahmedabad', '2022-06-07 21:38:18', '2022-06-07 21:38:18'),
(2, '2', 'ahmedabad', '2022-06-07 21:39:07', '2022-06-07 21:39:07'),
(3, '2', 'ahmedabad', '2022-06-07 21:40:25', '2022-06-07 21:40:25'),
(4, '2', 'ahmedabad', '2022-06-07 21:40:47', '2022-06-07 21:40:47'),
(5, '2', 'ahmedabad', '2022-06-07 21:42:24', '2022-06-07 21:42:24'),
(6, '2', 'ahmedabad', '2022-06-07 21:42:35', '2022-06-07 21:42:35'),
(7, '2', 'ahmedabad', '2022-06-07 21:42:40', '2022-06-07 21:42:40'),
(8, '2', 'ahmedabad', '2022-06-07 21:42:49', '2022-06-07 21:42:49'),
(9, '2', 'ahmedabad', '2022-06-07 21:43:21', '2022-06-07 21:43:21'),
(10, '2', 'ahmedabad', '2022-06-07 21:44:13', '2022-06-07 21:44:13'),
(11, '2', 'ahmedabad', '2022-06-07 21:44:32', '2022-06-07 21:44:32'),
(12, '2', 'ahmedabad', '2022-06-07 21:45:00', '2022-06-07 21:45:00'),
(13, '2', 'ahmedabad', '2022-06-07 21:45:09', '2022-06-07 21:45:09'),
(14, '2', 'ahmedabad', '2022-06-07 21:45:38', '2022-06-07 21:45:38'),
(15, '2', 'ahmedabad', '2022-06-07 21:46:15', '2022-06-07 21:46:15'),
(16, '2', 'ahmedabad', '2022-06-07 21:47:12', '2022-06-07 21:47:12'),
(17, '2', 'ahmedabad', '2022-06-07 21:49:15', '2022-06-07 21:49:15'),
(18, '2', 'ahmedabad', '2022-06-07 21:51:45', '2022-06-07 21:51:45'),
(19, '2', 'ahmedabad', '2022-06-07 21:52:51', '2022-06-07 21:52:51'),
(20, '2', 'ahmedabad', '2022-06-07 21:53:26', '2022-06-07 21:53:26'),
(21, '2', 'ahmedabad', '2022-06-07 21:53:40', '2022-06-07 21:53:40'),
(22, '2', 'ahmedabad', '2022-06-07 21:54:17', '2022-06-07 21:54:17'),
(23, '2', 'ahmedabad', '2022-06-07 21:54:24', '2022-06-07 21:54:24'),
(24, '2', 'ahmedabad', '2022-06-07 21:55:18', '2022-06-07 21:55:18'),
(25, '2', 'ahmedabad', '2022-06-07 21:55:31', '2022-06-07 21:55:31'),
(26, '2', 'ahmedabad', '2022-06-07 21:55:53', '2022-06-07 21:55:53'),
(27, '2', 'ahmedabad', '2022-06-07 21:56:11', '2022-06-07 21:56:11'),
(28, '2', 'ahmedabad', '2022-06-07 21:56:56', '2022-06-07 21:56:56'),
(29, '2', 'ahmedabad', '2022-06-07 21:57:24', '2022-06-07 21:57:24'),
(30, '2', 'ahmedabad', '2022-06-07 21:58:03', '2022-06-07 21:58:03'),
(31, '2', 'ahmedabad', '2022-06-07 21:58:30', '2022-06-07 21:58:30'),
(32, '2', 'ahmedabad', '2022-06-07 21:59:53', '2022-06-07 21:59:53'),
(33, '2', 'ahmedabad', '2022-06-07 22:00:37', '2022-06-07 22:00:37'),
(34, '2', 'ahmedabad', '2022-06-07 22:01:41', '2022-06-07 22:01:41'),
(35, '2', 'ahmedabad', '2022-06-07 22:03:40', '2022-06-07 22:03:40'),
(36, '2', 'ahmedabad', '2022-06-07 22:04:08', '2022-06-07 22:04:08'),
(37, '2', 'ahmedabad', '2022-06-07 22:04:45', '2022-06-07 22:04:45'),
(38, '2', 'ahmedabad', '2022-06-07 22:04:52', '2022-06-07 22:04:52'),
(39, '2', 'ahmedabad', '2022-06-07 22:05:02', '2022-06-07 22:05:02'),
(40, '2', 'ahmedabad', '2022-06-07 22:05:15', '2022-06-07 22:05:15'),
(41, '2', 'ahmedabad', '2022-06-07 22:06:41', '2022-06-07 22:06:41'),
(42, '2', 'ahmedabad', '2022-06-07 22:07:12', '2022-06-07 22:07:12'),
(43, '2', 'surat', '2022-06-07 22:07:41', '2022-06-07 22:07:41'),
(44, '2', 'talala', '2022-06-07 22:29:21', '2022-06-07 22:29:21'),
(45, '2', 'talala', '2022-06-07 22:29:34', '2022-06-07 22:29:34'),
(46, '2', 'talala', '2022-06-07 22:30:34', '2022-06-07 22:30:34'),
(47, '2', 'talala', '2022-06-07 22:30:58', '2022-06-07 22:30:58');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2022_06_07_165547_create_users_table', 1),
(2, '2022_06_08_024847_create_cities_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userToken` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `password`, `userToken`, `created_at`, `updated_at`) VALUES
(2, 'Test', '9090909090', '$2y$10$7SMPndXGRwwqDjjihhnvj.DKlD16y.uMRadUyjnUKfYI9MxZgWzRW', NULL, '2022-06-07 11:51:21', '2022-06-07 11:51:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
