<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title>Task</title>
  </head>
  <body>
    <h2>Weather Data</h2> <a href="{{ route('logout') }}">Logout</a>
    
    {{ Form::open(array('route' => 'getWeatherData', 'method' => 'post')) }}
    	@csrf
        <div class="form-group">
            <label for="exampleInputEmail1">City</label>
            <input type="text" class="form-control" name="city"  placeholder="Enter city">
        </div>
        
        <button type="submit" class="btn btn-primary">Submit</button>
	{{ Form::close() }}
    @if(empty(session('message')))
             {{ session('message') }}
    @endif
	@if(isset($data1))
        <table>
            <thead>
                <th style="width: 200px; border:1px solid black">Weather Date</th>
                <th style="width: 200px; border:1px solid black">Weather Main</th>
                <th style="width: 200px; border:1px solid black">Weather Description</th>
            </thead>
            <tbody>
            @foreach($data1['list'] as $d=>$value)
                    <tr style="border:1px solid black">
                        <td style="border:1px solid black">{{ $value['dt_txt'] }} </td>
                        <td style="border:1px solid black">{{ $value['weather'][0]['main'] }} </td>
                        <td style="border:1px solid black">{{ $value['weather'][0]['description'] }} </td>
                    </tr>
            @endforeach
            </tbody>
        </table>
    @endif
    
  </body>
</html>