<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for ($i=0; $i < 10; $i++) { 
	    	Product::create([
	            'name' => str_random(10),
	            'price' => '10',
	            'detail' => str_random(25)
	        ]);
    	}
    }
}
