<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<title>Listing Page</title>
<link href="<?php echo e(asset('front/css/style.css')); ?>" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FFF8E8" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!--title START-->
<table width="100%"  border="0" cellspacing="10" cellpadding="5" align="center">
 <tr>
    <td align="center" valign="middle" bgcolor="#FFF3D7" style="border-bottom: 1px solid #FFE29F;"><B><SPAN 
      class=heading11>Sample Test Project </SPAN><SPAN class=heading2></SPAN><BR>
      </B></td>
  </tr>
</table>
<!--title END-->
<!--body START-->
<table width="100%"  border="0" cellspacing="10" cellpadding="5" align="center">
        <form method="post" action="<?php echo e(url('/search/')); ?>">
            <?php echo csrf_field(); ?>
    		<tr>
    		<td align="left"><div style=" color: #a75314;font-family: Verdana,Arial,Helvetica,sans-serif;font-size: 12px;">Search : </div><input type="text" size="35" name="search" id="emailAddress" >
            <div id="emailList">
                
            </div>  
            <select>
                <option value="Oracle">Oracle</option>
                <option value="VB5">VB5</option>
            </select>  
            <input type="submit" value="Search" name="Submit"></td>
    		<td align="right"><a href="<?php echo e(url('/add/')); ?>">ADD NEW RECORD</a></td>
    		</tr>
        </form>
 <tr>
    <td colspan="2">
	<table width="100%"  border="0" align="center" cellpadding="2" cellspacing="2" class="heading6" style="border:1px solid #FFE29F;">
      <tr height="25">
        <!--<td width="28%" height="31" align="center" bgcolor="#FFF3D6" class="heading5"><div align="left">User Id </div></td>-->
		 <td width="11%" align="center" bgcolor="#FFF3D6" class="heading5"><div align="left">Profile Image ^</div></td>
        <td width="11%" align="center" bgcolor="#FFF3D6" class="heading5"><div align="left">Username ^</div></td>
        <td width="11%" align="center" bgcolor="#FFF3D6" class="heading5"><div align="left">Password</div></td>
        <td width="16%" align="center" bgcolor="#FFF3D6" class="heading5"><div align="left">Email Address </div></td>
        <td width="22%" align="center" colspan="2" bgcolor="#FFF3D6" class="heading5"><div align="left">Preferences</div></td>
        <td colspan="2" align="center" bgcolor="#FFF3D6" class="heading5">Options</td>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr valign="top" bgcolor="#FFFFFF">
            <!--<td align="left">de0bf4da130661a07d2d060c055721a3</td>-->
    		<td align="left"><img src="<?php echo e(asset('/uploads/User_images/'.$d->profile_image)); ?>" width="30px;" height="40px;"></td>
            <td align="left"><?php echo e($d->userName); ?></td>
            <td align="left"><?php echo e($d->password); ?></td>
            <td align="left"><?php echo e($d->emailAddress); ?></td>
            <?php $p =  App\Models\Preferences::where('userId',$d->id)->get();
                  $pname =  App\Models\Prefmaster::whereIn('preferenceId',explode(',',$p[0]->preferenceId))->get();
                  foreach($pname as $nm)
                  {
                     $name[] = $nm->preferenceName;
                  }
             ?>     
            <td align="left" colspan="2"><?php echo e(implode(',', $name)); ?><br>
              ASP.Net </td>
            <!--<td width="6%" align="center"><a href="#">EDIT</a></td>-->
            <td width="6%" colspan="2" align="center"><a href="<?php echo e(url('/edituser/'.$d->id)); ?>">EDIT</a> &nbsp; &nbsp; &nbsp; <a href="<?php echo e(url('/deleteuser/'.$d->id)); ?>">DELETE</a></td>
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  
    </table></td>
  </tr>
  <tr>
	<td> 
    <!-- <ul class="pagination">
  <li><a href="#">1</a></li>
  <li><a href="#">2</a></li>
  <li><a href="#">3</a></li>
  <li><a href="#">4</a></li>
  <li><a href="#">5</a></li>
</ul> -->
    Showing <?php echo e($data->firstItem()); ?> - <?php echo e($data->lastItem()); ?> of <?php echo e($data->total()); ?>

</td>

  </tr>
</table>
<!--body END-->
<!--bottom START-->
<table width="100%"  border="0" cellspacing="10" cellpadding="5" align="center">
 <TR vAlign=bottom align=left>
    <TD colSpan=3 height=40><SPAN class=heading4>© Sample project </SPAN><SPAN class=heading3><B></B></SPAN></TD>
 </TR>
</table>
<!--bottom END-->
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
    
         $('#emailAddress').keyup(function(){ 
                var query = $(this).val();
                if(query != '')
                {
                 var _token = $('input[name="_token"]').val();
                 $.ajax({
                    headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                  url:"<?php echo e(route('front.fetchemail')); ?>",
                  method:"POST",
                  data:{query:query, _token: $('meta[name="csrf-token"]').attr('content') },
                  success:function(data){
                   $('#emailList').fadeIn();  
                            $('#emailList').html(data);
                  }
                 });
                }
            });
        
            $(document).on('click', 'li', function(){  
                $('#emailAddress').val($(this).text());  
                $('#emailList').fadeOut();  
            });  
        
        });
</script>
</html>
<?php /**PATH C:\xampp\htdocs\Demo\resources\views/front/list.blade.php ENDPATH**/ ?>