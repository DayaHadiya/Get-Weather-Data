<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title>Product Management</title>
  </head>
  <body>
    <h2>Cart List</h2>  <a href="<?php echo e(route('logout')); ?>">Logout</a> | 
    <a href="<?php echo e(route('productList')); ?>">Product List</a> | 
    <a href="<?php echo e(route('cartList')); ?>">Cart List</a>
    
    <form class="form-inline" method="post" action="<?php echo e(route('search')); ?>">
    	<?php echo csrf_field(); ?>
	  <div class="form-group mx-sm-3 mb-2">
	    <label for="inputPassword2" class="sr-only">Select Brand</label>
	    	<select class="form-control" name="brand">
	    		<?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    			<option value="<?php echo e($b->brand); ?>"><?php echo e($b->brand); ?></option>
	    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    	</select>
	  </div>
	  <button type="submit" class="btn btn-primary mb-2">Search</button>
	</form>
	
	<table class="table">
	  <thead class="thead-dark">
	    <tr>
	      <th scope="col">User Name</th>
	      <th scope="col">Product Name</th>
	      <th scope="col">Detail</th>
	      <th scope="col">Total</th>
	    </tr>
	  </thead>
	  <tbody>
	  	<?php $total = 0; ?>
	  	<?php if(count($cartData) > 0): ?>
		  	<?php $__currentLoopData = $cartData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  	<?php $total += $p->total; ?>
		    <tr>
		      <td><?php echo e(Auth::user()->firstname); ?><?php echo e(Auth::user()->lastname); ?></</td>
		      <td><?php echo e($p->name); ?></td>
		      <td><?php echo e($p->detail); ?></td>
		      <td><?php echo e($p->total); ?></td>
		    </tr>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php else: ?>
			<tr><td>Data not found</td></tr>
		<?php endif; ?>
	  </tbody>
	  <tfoot>
	  <?php if(count($cartData) > 0): ?>	
	    <tr>
	    	<td></td>
	    	<td></td>
	    	<td><b>Final Total</b></td>
	    	<td><b><?php echo e($total); ?></b></td>
	    </tr>
	   <?php endif; ?>
	  </tfoot>
	</table>

		
		  
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH C:\xampp\htdocs\Demo\resources\views/front/cartlist.blade.php ENDPATH**/ ?>