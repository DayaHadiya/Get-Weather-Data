<!-- saved from url=(0022)http://internet.e-mail -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Add/Edit Details</title>
<link href="<?php echo e(asset('front/css/style.css')); ?>" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FFF8E8" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!--title START-->
<table width="100%"  border="0" cellspacing="10" cellpadding="5" align="center">
 <tr>
    <td align="center" valign="middle" bgcolor="#FFF3D7" style="border-bottom: 1px solid #FFE29F;"><B><SPAN 
      class=heading11>Sample Test Project </SPAN><SPAN class=heading2></SPAN><BR>
      </B></td>
  </tr>
</table>
<!--title END-->
<?php
        $label = "Add";
        $userName = "";
        $password = "";
        $emailAddress = "";
        $confirm_password = "";
        $profile_image = "";
        $contactNumber = "";
        $id = "";
        $isError = false;

        $formRoute = 'front.save';
        $clogo = asset('adminpanel/images/default-user.jpg');
        if(isset($data['error']))
        {
            $isError = true;
            if($data['type']=="edit")
            {
                $label = "Edit";
                $formRoute = 'front.update';
            }
            $userName = $data['input']['userName'];
            //$password = $data['input']['password'];
            $emailAddress = $data['input']['emailAddress'];
            //$confirm_password = $data['input']['confirm_password'];
            //$profile_image = $data['input']['profile_image'];
        }
        else
        {
            if($data['type'] == "Edit")
            {
                $label = "Edit";
                $userName = $data['input'][0]->userName;
                $password = $data['input'][0]->password;
                $emailAddress = $data['input'][0]->emailAddress;
                $confirm_password = $data['input'][0]->confirm_password;
                $profile_image = $data['input'][0]->profile_image;
                $id = $data['input'][0]->id;
                           
                if($profile_image!="" && $profile_image!=null)
                {
                    if(file_exists(public_path()."/uploads/User_images/".$profile_image))
                    {
                        $clogo = asset('/uploads/User_images/'.$profile_image);
                    }
                }
                $formRoute = 'front.update';
            }
        }
        ?>
<!--body START-->
<form method='post' action="<?php echo e(route($formRoute)); ?>" enctype='multipart/form-data'>
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($id); ?>">
<table width="100%"  border="0" cellspacing="10" cellpadding="5" align="center">
 <tr>
    <td><table width="70%"  border="0" align="center" class="heading6">
      <tr align="center">
        <td height="30" colspan="3" class="heading7"><?php echo e($label); ?> Details</td>
        </tr>
         <?php if($errors->any()): ?>
            <div class="error-message-box">                    
                <p><?php echo e($errors->first()); ?></p>
            </div>
        <?php endif; ?>
        <?php if($isError): ?>
            <div class="error-message-box">
                <?php foreach($data['error']->all() as $error) {
                    echo "<p>". $error . "</p>";
                } ?>
            </div>
        <?php endif; ?>
      <tr>
        <td width="49%" align="right">User Name*</td>
        <td width="4%" align="center">:</td>
        <td width="47%" align="left"><input name="userName" type="text" value="<?php echo e($userName); ?>" ></td><td> <input  type="button" name="Checkbutton" value="Check Availability" /><br />(ajax based functionality should be written)</td>
      </tr>
      <tr>
        <td align="right">Password*</td>
        <td align="center">:</td>
        <td align="left"><input name="password" value="<?php echo e($password); ?>" type="password" ></td>
      </tr>
	  <tr>
        <td align="right">Confirm Password*</td>
        <td align="center">:</td>
        <td align="left"><input name="confirm_password" value="<?php echo e($confirm_password); ?>" type="password" ></td>
      </tr>
      <tr>
        <td align="right">Email Address*</td>
        <td align="center">:</td>
        <td align="left"><input name="emailAddress" value="<?php echo e($emailAddress); ?>" type="email" ></td>
      </tr>
	  <tr>
        <td align="right">Profile Image*</td>
        <td align="center">:</td>
        <td align="left"><input name="profile_image" value="<?php echo e($profile_image); ?>" type="file" ></td>
      </tr>
	  <tr>
        <td align="right"></td>
        <td align="center"></td>
        <td align="left">(Jpeg,Jpg,Png, Max Limit:2MB)</td>
      </tr>
      <tr>
        <td colspan="4" align="left"><table width="100%"  border="0" cellspacing="2" cellpadding="2">
			(Please select minimum 3)
          <tr bgcolor="#FFF2D5" class="heading4">

            <?php if($data['type'] == "Edit") { $selectedP = explode(',',$spref[0]->preferenceId); }?>

            <?php $__currentLoopData = $pref; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td width="5%"><strong>&nbsp;
                    <input type="checkbox" name="preference[]" <?php if($data['type'] == "Edit" && in_array($p->preferenceId,$selectedP)){ ?> checked <?php  }?> value="<?php echo e($p->preferenceId); ?>">
                </strong></td>
                <td width="16%"><strong><?php echo e($p->preferenceName); ?></strong></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <!--  <td width="7%"><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td width="19%"><strong>C++</strong></td>
            <td width="5%"><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td width="23%"><strong>VB 5 </strong></td>
            <td width="5%"><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td width="20%"><strong>VB 6 </strong></td> -->
          </tr>
         <!--  <tr bgcolor="#FFF2D5" class="heading4">
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>Visual Studio.net </strong></td>
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>ASP</strong></td>
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>ASP.Net</strong></td>
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>C#</strong></td>
          </tr>
          <tr bgcolor="#FFF2D5" class="heading4">
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>Oracle</strong></td>
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>PHP</strong></td>
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>Java</strong></td>
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>SQL Server</strong></td>
          </tr>
          <tr bgcolor="#FFF2D5" class="heading4">
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>MySQL</strong></td>
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>Sybase</strong></td>
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>JSP</strong></td>
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>PERL</strong></td>
          </tr>
          <tr bgcolor="#FFF2D5" class="heading4">
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>Phython</strong></td>
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>Cold Fusion</strong></td>
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>Windows</strong></td>
            <td><strong>&nbsp;
                <input type="checkbox" name="checkbox">
            </strong></td>
            <td><strong>Linux</strong></td>
          </tr> -->
        </table></td>
        </tr>
      <tr>
        <td align="left">&nbsp;</td>
        <td align="center">&nbsp;</td>
        <td align="left"><input type="submit" name="Submit" value="Save">&nbsp;&nbsp;<input type="Reset" name="Reset" value="Reset">&nbsp;&nbsp;<input type="button" name="button" value="Clear" onClick="history.go(-1);"></td>
      </tr>
    </table>	</td>
  </tr>
</table>
</form>
<!--body END-->
<!--bottom START-->
<table width="100%"  border="0" cellspacing="10" cellpadding="5" align="center">
 <TR vAlign=bottom align=left>
    <TD colSpan=3 height=40><SPAN class=heading4>© Sample project </SPAN><SPAN class=heading3><B></B></SPAN></TD>
 </TR>
</table>
<!--bottom END-->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Demo\resources\views/front/add.blade.php ENDPATH**/ ?>