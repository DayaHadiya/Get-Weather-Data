<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title>Task</title>
  </head>
  <body>
    <h2>Weather Data</h2> <a href="<?php echo e(route('logout')); ?>">Logout</a>
    
    <?php echo e(Form::open(array('route' => 'getWeatherData', 'method' => 'post'))); ?>

    	<?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="exampleInputEmail1">City</label>
            <input type="text" class="form-control" name="city"  placeholder="Enter city">
        </div>
        
        <button type="submit" class="btn btn-primary">Submit</button>
	<?php echo e(Form::close()); ?>

    <?php if(empty(session('message'))): ?>
             <?php echo e(session('message')); ?>

    <?php endif; ?>
	<?php if(isset($data1)): ?>
        <table>
            <thead>
                <th style="width: 200px; border:1px solid black">Weather Date</th>
                <th style="width: 200px; border:1px solid black">Weather Main</th>
                <th style="width: 200px; border:1px solid black">Weather Description</th>
            </thead>
            <tbody>
            <?php $__currentLoopData = $data1['list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="border:1px solid black">
                        <td style="border:1px solid black"><?php echo e($value['dt_txt']); ?> </td>
                        <td style="border:1px solid black"><?php echo e($value['weather'][0]['main']); ?> </td>
                        <td style="border:1px solid black"><?php echo e($value['weather'][0]['description']); ?> </td>
                    </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
    
  </body>
</html><?php /**PATH C:\xampp\htdocs\TaskListBC\resources\views/front/addcity.blade.php ENDPATH**/ ?>