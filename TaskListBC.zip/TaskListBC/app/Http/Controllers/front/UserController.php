<?php

namespace App\Http\Controllers\front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\City;
use Hash;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function login()
    {
        return view('front.login');
    }

    public function register()
    {
        return view('front.register');
    }

    public function submitRegister(Request $request)
    {
        $input = $request->all();
        $validated = $request->validate([
            'phone' => 'required|min:10|max:10',
            'name' => 'required',
            'password' => 'required|alpha_num|min:8|max:8'
        ]);

        $input['password'] = bcrypt($input['password']);
        $user = User::create($input);
        if($user)
        {
            return view('front.login');
        }
        else
        {
            return view('front.register');
        }
    }

    public function submitlogin(Request $request)
    {
        $input = $request->all();
        if(Auth::guard('web')->attempt(['phone' => $input['phone'], 'password' => $input['password']], false))
        {
            
            return view('front.addcity');
        }
        else
        {
            return view('front.login')->with('message','Please enter correct detail');
        }
    }

    public function getWeatherData(Request $request)
    {
        $input = $request->all();
        $location = $input['city'];
        $apikey = '3a1f0be9da17c360c58c227e3a57bcdd';
        $url  = 'api.openweathermap.org/data/2.5/weather?q='.$location.'&appid='.$apikey.'&units=metric';
        

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec ($ch);
        $err = curl_error($ch);  //if you need
        curl_close ($ch);
        $data = json_decode($response,true);
        //return $data;
        if ($data['cod'] != '404')
        {
            $x = $data["coord"];
            $lon = $x['lon'];
            $lat = $x['lat'];
            //return $response;
            $url1 = 'api.openweathermap.org/data/2.5/forecast?lat='.$lat.'8&lon='.$lon.'&appid='.$apikey;
            $ch1 = curl_init();
            curl_setopt($ch1, CURLOPT_URL, $url1);
            curl_setopt($ch1, CURLOPT_POST, 0);
            curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);

            $response1 = curl_exec ($ch1);
            $err1 = curl_error($ch1);  //if you need
            curl_close ($ch1);
            $data1 = json_decode($response1,true);
            //$weatherData = $data1["weather"];
            //$dateData = $data1["dt_txt"];
            $addCity['name'] = $input['city'];
            $addCity['user_id'] = Auth::user()->id;
            City::create($addCity);
            //return $response1;
            return view('front.addcity',compact('data1'));
        }
        else 
        {
           return view('front.addcity')->with('message','Data Not Found');
        }

    }
    public function logout(){
        //echo $user = Auth::user()->id;
        Auth::logout();
        return view('front.login');
    }
}
